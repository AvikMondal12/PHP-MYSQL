<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
     
        if ($_SERVER["REQUEST_METHOD"] == "POST") { 
        // Check if file was uploaded without errors 
        if (isset($_FILES["simplefile"])&& $_FILES["simplefile"]["error"] == 0  ) { 
           $file_name     = $_FILES["simplefile"]["name"]; 
           $file_tmp_name = $_FILES["simplefile"]["tmp_name"]; 
           $file_type     = $_FILES["simplefile"]["type"]; 
           $file_size     = $_FILES["simplefile"]["size"]; 
           $file_error    = $_FILES["simplefile"]["error"]; 

           echo "Uploaded File Name-" . $file_name . "<br>"; 
           echo "Temporary File Name-" . $file_tmp_name . "<br>";  
           echo "Type of File-" . $file_type . "<br>"; 
           echo "Number of bytes-" . $file_size . "<br>"; 
           echo "Error-" . $file_error . "<br>"; 
               
        } 
        }
    ?>
<!-- && $_FILES["simplefile"]["error"] == 0 -->
</body>
</html>